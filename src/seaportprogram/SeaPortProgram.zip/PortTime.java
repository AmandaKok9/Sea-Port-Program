/*File: PortTime.java
 *Date: 8/27/18
 *Author: Amanda Kok
 *Purpose:This class is not necessary for this project. The code here is a outline
 *for future implementation.
 */
package seaportprogram;

public class PortTime {
    
    private int time;
}
