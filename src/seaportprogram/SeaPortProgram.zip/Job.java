/*File: Job.java
 *Date: 8/27/18
 *Author: Amanda Kok
 *Purpose: This class is not necessary for this project. The code here is a outline
 *for future implementation.
 */

package seaportprogram;

import java.util.ArrayList;
import java.util.Scanner;

public class Job extends Thing {
    
    private double duration;
    private ArrayList<String> requirements;
    
    public Job(Scanner scanner){
        
    }//end constructor, functionality will be added in future projects
    
    @Override
    public String toString(){
        String description = "";
        return description;
    }
}//end Job class
